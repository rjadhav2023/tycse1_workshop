function sumArrayElements(arr) {
    return new Promise((resolve, reject) => {
      if (arr.length < 5) {
        reject(new Error("Array must contain at least 5 elements"));
      } else {
        const sum = arr.reduce((total, current) => total + current, 0);
        resolve(sum);
      }
    });
  }
  
  const myArray = [1, 2, 3, 4, 5, 6]; // An array with at least 5 elements
  
  sumArrayElements(myArray)
    .then((result) => {
      console.log("Sum:", result);
    })
    .catch((error) => {
      console.error("Error:", error.message);
    });
  