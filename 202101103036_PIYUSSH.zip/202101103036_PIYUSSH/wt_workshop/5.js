sayHi=(name)=>{
    console.log('hello from : ',name)
}
const sayBye=(name)=>{
    console.log('Bye from : ',name)
}
module.exports={sayHi,sayBye}