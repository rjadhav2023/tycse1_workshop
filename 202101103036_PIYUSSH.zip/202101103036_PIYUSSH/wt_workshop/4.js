var tester = "hey hi!!";
console.log(tester);

function newfunction() {
    var tester = "I am fine";
    console.log("Inside the function ", tester);
}
newfunction();

console.log(name); // This will log "undefined"
var name = "somename";

const value1 = 10;
const value2 = 20;

var data1 = 10;
data1 = 20; // Corrected to reassign the value

console.log(value1);
// const value1 = 100; // This line is commented out to prevent a reassignment error


