var mysql  = require('mysql');
var dbconn = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '1234567890',
  database : 'piyussh'


});
 
dbconn.connect(function(err){
  if(err){
    console.log('Database connection error');
  }else{
    console.log('Database connection successful');
  }
});

//
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  con.query("CREATE DATABASE Piyussh", function (err, result) {
    if (err) throw err;
    console.log("Database created");
  });
});

//
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  var sql = "CREATE TABLE records (name VARCHAR(255), mail VARCHAR(255), pass VARCHAR(255))";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table created");
  });
});

//
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  var sql = "INSERT INTO records (name, mail, pass) VALUES ('Rahul', 'trade@gmail.com', 'pass123')";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
  });
});
  //Select all customers and return the result object:
  dbconn.query("SELECT * FROM records", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    //console.log('field length:',fie)
    result.forEach( (row) => {
        console.log(`${row.name} : ${row.mail}`);
      });
     
  });
