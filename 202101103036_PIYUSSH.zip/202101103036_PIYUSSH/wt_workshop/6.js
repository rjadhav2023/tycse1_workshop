const greet=require('./5.js')
greet.sayHi('Piyussh')
greet.sayBye('Prathamesh')