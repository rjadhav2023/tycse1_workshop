var arr = ['cat','dog','swan']
console.log(arr)
console.log(arr[0])
arr.forEach((animal)=>{
    console.log(animal)
})

var cattype=arr[0];

var arr1=arr.map((animalName)=>animalName.toUpperCase())
console.log(arr)
console.log(arr1)

arr1.push('horse')
console.log(arr1)

arr1.filter((element)=>element.lenght<4)
console.log(arr1)

//Array destructing
const profile=['Piyussh','Baraskar','baraskarpiyussh2004@gmail.com']
const [firstname,lastname,email] = profile;
console.log(firstname) 
console.log(lastname) 
console.log(email) 

const profile1=['Piyussh','Baraskar','baraskarpiyussh2004@gmail.com']
const [fisrtname, ...details] = profile;

console.log(firstname);
console.log(details); 

