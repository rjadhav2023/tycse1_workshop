const amount=9
if(amount<10){
    console.log('condition satisfied')
}
else{
    console.log('condition not satisfied')
}
console.log(amount)
console.log('the value of amount=',amount)
console.log('${amount}')

