//traditional method
const profile={
    fisrtname: 'Piyussh',
    lastname: 'baraskar',
    email: 'baraskarpiyussh2004@gmail.com'
}
const fisrtname = profile.fisrtname;
const lastname = profile.lastname;
const email = profile.email;

console.log(fisrtname);
console.log(lastname);
console.log(email);

