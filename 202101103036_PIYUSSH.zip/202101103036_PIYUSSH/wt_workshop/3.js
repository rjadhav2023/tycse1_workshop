const greet = () => {
    console.log('Greetings');
}

const greetWithName = (name) => {
    console.log(`Greetings ${name}`);
}

const greetWithDefaultName = (name = 'Piyussh') => {
    console.log(`Greetings ${name}`);
}

// Calling the functions
greet(); // Greetings
greetWithName('John'); // Greetings John
greetWithDefaultName(); // Greetings Piyussh
