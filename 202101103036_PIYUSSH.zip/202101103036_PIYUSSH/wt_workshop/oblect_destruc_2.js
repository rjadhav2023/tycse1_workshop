//modern technique
const profile={
    fisrtname: 'Piyussh',
    lastname: 'baraskar',
    email: 'baraskarpiyussh2004@gmail.com'
};
const {fisrtname: fisrtname, lastname: lastname, email: email} = profile;

console.log(fisrtname);
console.log(lastname);
console.log(email);