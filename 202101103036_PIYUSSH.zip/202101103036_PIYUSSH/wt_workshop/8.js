//asynchronus programming
var fs = require('fs');

fs.readFile('./content/fist.txt', 'utf8', function(err, data) {
  if (err) {
    console.error(err);
    return;
  }
  console.log(data); 
  console.log('reading completed');
});

console.log('Reading file...');
