//promising pipeline
const multiplication=(num1, num2)=>{
    return new Promise((resolve, reject) => {
        setTimeout(()=>{
            if(num1<0 || num2<0){
            return reject("only positive numbers allowed")
            }
            resolve(num1*num2)
        },4000)
    })
}
multiplication(-5,-6).then((product)=>{
    console.log('product')
}).catch((error)=> console.log(error))
