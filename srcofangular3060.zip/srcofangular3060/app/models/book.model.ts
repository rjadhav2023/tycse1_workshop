export class Book {
  id?: any;
  title?: string;
  description?: string;
  published?: boolean;
}
