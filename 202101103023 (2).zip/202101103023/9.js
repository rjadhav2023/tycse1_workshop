var fs = require("fs");
fs = fs.readFile("./content/first.txt", function (arr, data) {
  if (arr) return console.error(err);
  console.log(data.toString);
});
console.log("reading completed");
console.log("activity started");
setTimeout(() => {
  console.log("do something");
}, 2000);
console.log("activity completed");
