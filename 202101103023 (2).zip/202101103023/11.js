function addArrayElements(array) {
  return new Promise((resolve, reject) => {
    if (!Array.isArray(array) || array.length < 5) {
      reject(new Error("Array should contain at least 5 elements"));
    } else {
      const sum = array.reduce((acc, current) => acc + current, 0);
      resolve(sum);
    }
  });
}

// Example usage:
const myArray = [1, 2, 3, 4, 5, 6];
addArrayElements(myArray)
  .then((result) => {
    console.log("Sum of array elements:", result);
  })
  .catch((error) => {
    console.error("Error:", error.message);
  });
