var arr = ["cat", "bat"];
console.log(arr);
console.log(arr[0]);
arr.forEach((item) => {
  console.log(item);
});
var cattype = arr[0];
var arr1 = arr.map((animalName) => (animalName = animalName.toUpperCase()));

console.log(arr);
console.log(arr1);
arr1.push("horse");
console.log(arr1);
arr1.filter((element) => element.length < 4);
console.log(arr1);

const profile = ["sneha", "kathar", "katharsneha7@gmail.com"];
const [firstname, lastname, email] = profile;
console.log(firstname);
console.log(lastname);
console.log(email);

const profile1 = ["sneha", "kathar", "katharsneha7@gmail.com"];
const [firstname1, ...details] = profile;
console.log(firstname);
console.log(details);
